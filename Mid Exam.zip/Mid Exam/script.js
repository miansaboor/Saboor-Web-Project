let tasks = [];

const form = document.getElementById("taskForm");
const taskList = document.getElementById("taskList");
const filter = document.getElementById("filter");

form.addEventListener("submit", (e) => {
    e.preventDefault();

    const taskName = document.getElementById("taskName").value;
    const subject = document.getElementById("subject").value;
    const dueDate = document.getElementById("dueDate").value;

    tasks.push({ taskName, subject, dueDate });
    displayTasks(tasks);

    form.reset();
});

const displayTasks = (taskArray) => {
    taskList.innerHTML = "";

    taskArray.forEach(({ taskName, subject, dueDate }) => {
        let row = `
            <tr>
                <td>${taskName}</td>
                <td>${subject}</td>
                <td>${dueDate}</td>
            </tr>
        `;
        taskList.innerHTML += row;
    });
};

filter.addEventListener("change", () => {
    let value = filter.value;

    if (value === "all") {
        displayTasks(tasks);
    } else {
        let filtered = tasks.filter(t => t.subject === value);
        displayTasks(filtered);
    }
});

const sortTasks = () => {
    tasks.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate));
    displayTasks(tasks);
};

fetch("https://jsonplaceholder.typicode.com/todos?_limit=5")
    .then(res => res.json())
    .then(data => {
        const apiList = document.getElementById("apiData");
        data.forEach(item => {
            let li = document.createElement("li");
            li.textContent = item.title;
            apiList.appendChild(li);
        });
    });